ibmc_raid 'get' do
  action :get
end
