ibmc_health_drive 'get' do
  action :get
end
