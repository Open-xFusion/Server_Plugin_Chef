## 1.0.0
Initial release. Add Chef resources to config XFUSION iBMC using iBMC REST API.
