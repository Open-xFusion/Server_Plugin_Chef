#
# Cookbook:: chef-ibmc-cookbook
# Resource:: ibmc_sp_firmware
#
# Copyright:: 2019, The Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

require_relative 'base_resource'
require_relative 'const'

module IbmcCookbook
  class IbmcSp < BaseResource
    resource_name :ibmc_sp
    provides :ibmc_sp

    property :start_enabled, [true, false]
    property :sys_restart_delay_seconds, Integer
    property :timeout, Integer
    property :finished, [true, false]
    
    action :set do
      arg = build_optional_arg_str(
        '-S': new_resource.start_enabled,
        '-T': new_resource.sys_restart_delay_seconds,
        '-O': new_resource.timeout,
        '-F': new_resource.finished
      )
      # Set SP start enabled
      subcmd = Const::Subcmd::SET_SP_INFO.to_cmd(arg)
      call_urest(subcmd)

      # reset_type = 'ForceRestart'
      # # Restart OS
      # subcmd = Const::Subcmd::SYS_POWER_CTRL.to_cmd(reset_type)
      # call_urest(subcmd)
    end

    action :result do
      subcmd = Const::Subcmd::GET_SP_RESULT.to_cmd()
      call_urest(subcmd)
    end
  end
end
