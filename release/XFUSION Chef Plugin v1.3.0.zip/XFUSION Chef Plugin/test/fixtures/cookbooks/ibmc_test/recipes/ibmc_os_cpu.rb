ibmc_cpu 'get' do
  action :get
end
