ibmc_health_psu 'get' do
  action :get
end
