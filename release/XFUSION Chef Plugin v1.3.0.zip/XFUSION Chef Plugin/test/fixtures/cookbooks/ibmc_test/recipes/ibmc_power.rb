ibmc_restart 'restart' do
  action :restart
end
