ibmc_ethernet 'get' do
  action :get
end
