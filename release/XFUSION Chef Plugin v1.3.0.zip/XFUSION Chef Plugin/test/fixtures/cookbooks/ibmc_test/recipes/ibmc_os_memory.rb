ibmc_memory 'get' do
  action :get
end
