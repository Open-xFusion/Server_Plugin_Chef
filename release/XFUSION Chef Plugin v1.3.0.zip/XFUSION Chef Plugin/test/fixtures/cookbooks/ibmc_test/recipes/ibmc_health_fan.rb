ibmc_health_fan 'get' do
  action :get
end
