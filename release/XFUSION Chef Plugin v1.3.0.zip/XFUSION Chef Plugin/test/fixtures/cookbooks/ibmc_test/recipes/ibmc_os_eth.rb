ibmc_os_eth 'get' do
  action :get
end
