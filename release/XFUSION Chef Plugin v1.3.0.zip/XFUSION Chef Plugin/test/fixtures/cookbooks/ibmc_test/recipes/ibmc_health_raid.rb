ibmc_health_raid 'get' do
  action :get
end
